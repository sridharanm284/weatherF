import React, { useEffect, useRef, useState } from 'react';

const MapComponent: React.FC = () => {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const [map, setMap] = useState<any>(null);
  const [activeLayer, setActiveLayer] = useState<string>('wind');
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number | null>(null);
  const timeSliderRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    const loadMap = () => {
      maptilersdk.config.apiKey = 'FJMJQLb9VrXJoMPWvEaF'; 

      const mapInstance = new maptilersdk.Map({
        container: mapContainerRef.current!,
        style: maptilersdk.MapStyle.BACKDROP,
        zoom: 1,
        center: [-42.66, 37.63],
        hash: true,
      });

      setMap(mapInstance);

      mapInstance.on('load', () => {
        mapInstance.setPaintProperty("Water", 'fill-color', "rgba(0, 0, 0, 0.4)");
        initWeatherMap('wind');
      });
    };

    loadMap();
  }, []);

  const weatherLayers: { [key: string]: any } = {
    "precipitation": { layer: null, value: "value", units: " mm" },
    "pressure": { layer: null, value: "value", units: " hPa" },
    "radar": { layer: null, value: "value", units: " dBZ" },
    "temperature": { layer: null, value: "value", units: "°" },
    "wind": { layer: null, value: "speedMetersPerSecond", units: " m/s" }
  };

  const initWeatherMap = (type: string) => {
    changeWeatherLayer(type);
  };

  const changeWeatherLayer = (type: string) => {
    if (type !== activeLayer) {
      if (map && map.getLayer(activeLayer)) {
        const activeWeatherLayer = weatherLayers[activeLayer]?.layer;
        if (activeWeatherLayer) {
          setCurrentTime(activeWeatherLayer.getAnimationTime());
          map.setLayoutProperty(activeLayer, 'visibility', 'none');
        }
      }
      setActiveLayer(type);
      const weatherLayer = weatherLayers[type].layer || createWeatherLayer(type);
      if (map && map.getLayer(type)) {
        map.setLayoutProperty(type, 'visibility', 'visible');
      } else {
        map?.addLayer(weatherLayer, 'Water');
      }
      changeLayerLabel(type);
      activateButton(type);
      changeLayerAnimation(weatherLayer);
      return weatherLayer;
    }
  };



  const createWeatherLayer = (type: string) => {
    let weatherLayer = null;
    switch (type) {
      case 'precipitation':
        weatherLayer = new maptilerweather.PrecipitationLayer({ id: 'precipitation' });
        break;
      case 'pressure':
        weatherLayer = new maptilerweather.PressureLayer({ opacity: 0.8, id: 'pressure' });
        break;
      case 'radar':
        weatherLayer = new maptilerweather.RadarLayer({ opacity: 0.8, id: 'radar' });
        break;
      case 'temperature':
        weatherLayer = new maptilerweather.TemperatureLayer({ colorramp: maptilerweather.ColorRamp.builtin.TEMPERATURE_3, id: 'temperature' });
        break;
      case 'wind':
        weatherLayer = new maptilerweather.WindLayer({ id: 'wind' });
        break;
    }

    weatherLayer.on("tick", () => {
      refreshTime();
      updatePointerValue();
    });

    weatherLayer.on("animationTimeSet", () => {
      refreshTime();
    });

    weatherLayer.on("sourceReady", () => {
      const startDate = weatherLayer.getAnimationStartDate();
      const endDate = weatherLayer.getAnimationEndDate();
      const timeSlider = timeSliderRef.current!;
      if (timeSlider.min > '0') {
        weatherLayer.setAnimationTime(currentTime!);
        changeLayerAnimation(weatherLayer);
      } else {
        const currentDate = weatherLayer.getAnimationTimeDate();
        timeSlider.min = startDate.toString();
        timeSlider.max = endDate.toString();
        timeSlider.value = currentDate.toString();
      }
    });

    weatherLayers[type].layer = weatherLayer;
    return weatherLayer;
  };

  const updatePointerValue = () => {
    
  };

  const changeLayerLabel = (type: string) => {
    const variableNameDiv = document.getElementById("variable-name");
    if (variableNameDiv) {
      variableNameDiv.innerText = type;
    }
  };

  const activateButton = (activeLayer: string) => {
    const buttons = document.getElementsByClassName('button');
    for (let i = 0; i < buttons.length; i++) {
      const btn = buttons[i];
      if (btn.id === activeLayer) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    }
  };

  const changeLayerAnimation = (weatherLayer: any) => {
    const timeSlider = timeSliderRef.current!;
    weatherLayer.setAnimationTime(parseInt(timeSlider.value) / 1000);
    if (isPlaying) {
      playAnimation(weatherLayer);
    } else {
      pauseAnimation(weatherLayer);
    }
  };

  const playAnimation = (weatherLayer: any) => {
    weatherLayer.animateByFactor(3600);
    const playPauseButton = document.getElementById('play-pause-bt');
    if (playPauseButton) {
      playPauseButton.innerText = "Pause";
    }
    setIsPlaying(true);
  };

  const pauseAnimation = (weatherLayer: any) => {
    weatherLayer.animateByFactor(0);
    const playPauseButton = document.getElementById('play-pause-bt');
    if (playPauseButton) {
      playPauseButton.innerText = "Play 3600x";
    }
    setIsPlaying(false);
  };

  const refreshTime = () => {
    const weatherLayer = weatherLayers[activeLayer]?.layer;
    if (weatherLayer) {
      const d = weatherLayer.getAnimationTimeDate();
      const timeTextDiv = document.getElementById("time-text");
      if (timeTextDiv) {
        timeTextDiv.innerText = d.toString();
      }
      const timeSlider = timeSliderRef.current!;
      timeSlider.value = d.toString();
    }
  };

  return (
    <div>
      <div
        id="time-info"
        style={{
          position: 'fixed',
          width: '60vw',
          bottom: 0,
          zIndex: 1,
          margin: '10px',
          textShadow: '0px 0px 5px black',
          color: 'white',
          fontSize: '18px',
          fontWeight: 500,
          textAlign: 'center',
          left: 0,
          right: 0,
          marginLeft: 'auto',
          marginRight: 'auto',
          padding: '20px'
        }}
      >
       
      </div>
      <div
        id="map"
        ref={mapContainerRef}
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '75%', 
          height: '40%' 
        }}
      >
         <span id="time-text" style={{ fontSize: '12px', fontWeight: 600 }}></span>
        <button
          id="play-pause-bt"
          className="btn btn-primary btn-sm time-button"
          onClick={() => {
            const weatherLayer = weatherLayers[activeLayer]?.layer;
            if (weatherLayer) {
              if (isPlaying) {
                pauseAnimation(weatherLayer);
              } else {
                playAnimation(weatherLayer);
              }
            }
          }}
        >
          Play 3600x
        </button>
        <input
          type="range"
          id="time-slider"
          ref={timeSliderRef}
          className="form-range time-button"
          style={{
            width: '100%',
            height: 'fit-content',
            left: 0,
            right: 0,
            zIndex: 1,
            filter: 'drop-shadow(0 0 7px #000a)',
            marginTop: '10px'
          }}
        />
      </div>
      <ul
        id="buttons"
        style={{
          width: 'auto',
          margin: '0 10px',
          padding: 0,
          position: 'absolute',
          top: '50px',
          left: 0,
          zIndex: 99
        }}
      >
        {['precipitation', 'pressure', 'radar', 'temperature', 'wind'].map((layer) => (
          <li key={layer} style={{ marginBottom: '10px' }}>
            <button
              id={layer}
              className="btn btn-primary button"
              onClick={() => changeWeatherLayer(layer)}
              style={{
                display: 'block',
                position: 'relative',
                width: '100%', 
                fontSize: '0.9em'
              }}
            >
              {layer.charAt(0).toUpperCase() + layer.slice(1)}
            </button>
          </li>
        ))}
      </ul>
      <div
        id="pointer-data"
        style={{
          zIndex: 1,
          position: 'fixed',
          fontSize: '20px',
          fontWeight: 900,
          margin: '27px 0px 0px 10px',
          color: '#fff',
          textShadow: '0px 0px 10px #0007'
        }}
      ></div>
      <div
        id="variable-name"
        style={{
          zIndex: 1,
          position: 'fixed',
          fontSize: '20px',
          fontWeight: 500,
          margin: '5px 0px 0px 10px',
          color: '#fff',
          textShadow: '0px 0px 10px #0007',
          textTransform: 'capitalize'
        }}
      ></div>
    </div>
  );
};

export default MapComponent;
