import React, { useState, useRef, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from 'axios';
import { useSelector } from "react-redux";
import store from "../../store";
import Box from "@mui/material/Box";
import { styled } from "@mui/material/styles";
import { Card, Typography, CardMedia, CardContent, Grid } from "@mui/material";
import MuiAppBar, { AppBarProps as MuiAppBarProps } from "@mui/material/AppBar";
import CardPlan from "../../components/dashboard/card";
import MapComponent from '../MapComponent';
import squall from "./../../assets/squall.png";
import typhoon from "./../../assets/typhoon.png";
import forecast from "./../../assets/forecast.png";
import lightning from "./../../assets/lightning.png";
import quickOverview from "./../../assets/quick-overview.png";
import weatherWindow from "./../../assets/weather-window.png";
// import "./styles/_index.scss";
import "./style.scss";
// import "./../../container/dashboard/styles";
// import './path-to-your-combined-scss-file.scss';


const drawerWidth = 0;

const Main = styled("main", { shouldForwardProp: (prop) => prop !== "open" })<{
  open?: boolean;
}>(({ theme, open }) => ({
  flexGrow: 1,
  padding: theme.spacing(3),
  transition: theme.transitions.create("margin", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  marginLeft: `-${drawerWidth}px`,
  ...(open && {
    transition: theme.transitions.create("margin", {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
    marginLeft: 0,
  }),
}));

interface AppBarProps extends MuiAppBarProps {
  open?: boolean;
}

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== "open",
})<AppBarProps>(({ theme, open }) => ({
  transition: theme.transitions.create(["margin", "width"], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    width: `calc(100% - ${drawerWidth}px)`,
    marginLeft: `${drawerWidth}px`,
    transition: theme.transitions.create(["margin", "width"], {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

interface CardData {
  name: string;
  url: string;
  image: string;
  content: string;
  color?: string;
}

const CardPlanComponent: React.FC = () => {
  const [data, setData] = useState<CardData[]>([]);
  const [stormData, setStormData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchStormData = () => {
    axios
      .get("http://localhost:8000/api/stormdatas/")
      .then((response) => {
        const data = response.data;
        if (data && data.track_datas) {
          setStormData(data.track_datas);
        } else {
          setStormData([]);
        }
        setLoading(false);
        setError(null);
      })
      .catch((error) => {
        console.error('Error fetching storm data:', error);
        setError('Error fetching storm data');
        setLoading(false);
      });
  };

  const fetchLastEditedData = async () => {
    const fid = localStorage.getItem("fid");

    if (fid) {
      try {
        const response = await axios.get(`http://localhost:8000/api/lastedited/${fid}`);
        const lastEditedData = response.data;

        const cardData: CardData[] = [
          {
            name: "Forecast",
            url: "forecast",
            image: forecast,
            content: lastEditedData.forecast
              ? `Last edited ${returnTimeDifference(lastEditedData.forecast)} ago`
              : "",
          },
          {
            name: "Quick Overview",
            url: "overview",
            image: quickOverview,
            content: lastEditedData.quick_overview
              ? `Last edited ${returnTimeDifference(lastEditedData.quick_overview)} ago`
              : "",
          },
          {
            name: "Weather Window",
            url: "weather",
            image: weatherWindow,
            content: lastEditedData.weather_window
              ? `Last edited ${returnTimeDifference(lastEditedData.weather_window)} ago`
              : "",
          },
          {
            name: "Squall",
            url: "squall",
            image: squall,
            content: "",
            color: "green",
          },
          {
            name: "Typhoon",
            url: "typhoon",
            image: typhoon,
            content: lastEditedData.typhoon
              ? `Last edited ${returnTimeDifference(lastEditedData.typhoon)} ago`
              : "",
            color: stormData.length === 0 ? "green" : "red",
          },
          {
            name: "Lightning",
            url: "lightning",
            image: lightning,
            content: "",
            color: "green",
          },
        ];

        setData(cardData);
      } catch (error) {
        console.error("Error fetching last edited data:", error);
      }
    }
  };

  const returnTimeDifference = (time: string): string => {
    const dataTime: Date = new Date(time);
    const now: Date = new Date();
    const seconds: number = Math.round((now.getTime() - dataTime.getTime()) / 1000);

    if (seconds > 86400) {
      return `${Math.round(seconds / (3600 * 24))} days`;
    } else if (seconds > 3600) {
      return `${Math.round(seconds / 3600)} hours`;
    } else {
      return `${Math.round(seconds / 60)} minutes`;
    }
  };

  useEffect(() => {
    fetchStormData();
    fetchLastEditedData();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="container">
      <MapComponent />

      <Grid container spacing={2} style={{ marginTop: '320px' }}>
        {data.map((item: CardData) => (
          <Grid item key={item.name} xs={12} sm={6} md={6} lg={4}>
            <Link to={`/${item.url}`} state={{ title: item.name }}>
            <div className="hoverable">
  <CardMedia
    className="card-img"
    sx={{ height: 100 }}
    image={item.image}
    title={item.name}
    style={{ borderRadius: "10px" }}
  />
  <Card className="parent_card" style={{ borderRadius: "10px" }}>
    <CardContent
      className="child_card"
      style={{
        display: "flex",
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
      }}
    >
      <div>
        <Typography gutterBottom variant="h6" component="div">
          {item.name}
        </Typography>
        <Typography variant="body2" color="text.secondary" style={{ fontSize: "0.8rem" }}>
          {item.content}
        </Typography>
      </div>
      {item.color && (
        <span
          className={`color_icon ${
            item.color === "red"
              ? "color_icon_red blinking-circle"
              : `color_icon_${item.color}`
          }`}
        ></span>
      )}
    </CardContent>
  </Card>
</div>

            </Link>
          </Grid>
        ))}
      </Grid>
    </div>
  );
};

export default function DashBoard() {
  // Reference value for current Browser Window Width
  const windowWidth = useRef(window.innerWidth);
  const [stormData, setStormData] = useState([]);
  const [mapHovers, setMapHovers] = useState<any>([]);
  const [loadedDatas, setLoadedDatas] = useState(false);
  // Sets Track about the SideNav Bar Open/Close State
  const [open, setOpen] = useState(windowWidth.current > 1000 ? true : false);
  const data = useSelector((state: any) => state?.app);

  useEffect(() => {
    store.dispatch({
      type: "TOGGLE_MENU",
      payload: windowWidth.current > 1000 ? true : false,
    });
  }, []);

  useEffect(() => {
    setOpen(data.toggle);
  }, [data]);

  useEffect(() => {
    if (loadedDatas) {
      return;
    }
    fetch("http://localhost:8000/api/stormdatas/")
      .then((data) => data.json())
      .then((data) => {
        setStormData(data.track_datas);
        setMapHovers(data.map_hovers);
        setLoadedDatas(true);
      })
      .catch((error) => setLoadedDatas(true));
  });

  return (
    <div className={open ? "sideNavOpen" : "sideNavClose"}>
      <Box className="fug-container bg-default flex sidenav-full">
        <div className="content-wrap dashboard">
          <Main open={open} className={"main"}>
            <Grid container spacing={2} display={"flex"} alignItems={"center"}>
              <Grid xs={12} md={9}>
                <Grid container spacing={3}>
                  <CardPlanComponent />
                </Grid>
              </Grid>
              <Grid xs={12} md={3} marginTop={"2em"} height={"63vh"}>
                <Card
                  style={{
                    height: "100%",
                    borderRadius: "15px",
                  }}
                >
                  <Grid xs={12} sx={{ height: 150 }}>
                    <Typography
                      variant="body2"
                      color="text.secondary"
                      style={{ textAlign: "center" }}
                    >
                      Active Warnings
                    </Typography>
                  </Grid>
                  <Grid xs={12} sx={{ height: 150 }}>
                    <Typography
                      variant="body2"
                      color="text.secondary"
                      style={{ textAlign: "center" }}
                    >
                      Squall Warnings
                    </Typography>
                  </Grid>
                  <Grid xs={12} sx={{ height: 150 }}>
                    <Typography
                      variant="body2"
                      color="text.secondary"
                      style={{ textAlign: "center" }}
                    >
                      Typhoon Warnings
                    </Typography>
                    {((stormData === undefined) ? [] : stormData).map((data: any) =>
                        mapHovers[`storm_${data.storm_track_id}`] !==
                          undefined &&
                        mapHovers[`storm_${data.storm_track_id}`].lon !==
                          undefined && (
                          <Typography
                            key={data.storm_track_id}
                            className={`blink-text-red`}
                            style={{
                              textAlign: "center",
                              paddingBlock: "5px",
                              color: "red",
                            }}
                          >
                            {data.storm_name === undefined
                              ? ""
                              : `${data.storm_name} - ${data.created_on
                                  .split("-")
                                  .slice(1, 3)
                                  .join("/")}`}
                          </Typography>
                        )
                    )}
                  </Grid>
                </Card>
              </Grid>
            </Grid>
          </Main>
        </div>
      </Box>
    </div>
  );
}
