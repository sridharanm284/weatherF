// src/components/ThemeToggle.js
import React, { useContext, useEffect } from 'react';
import ThemeContext from '../ThemeContext';
import DarkModeIcon from '@mui/icons-material/DarkMode';
import { MenuItem, Switch } from '@mui/material';

const ThemeToggle = () => {
  const { theme, toggleTheme } = useContext(ThemeContext);
  const [themeSwitch, setThemeSwitch] = React.useState(theme.palette.mode === 'dark');

  useEffect(() => {
    setThemeSwitch(theme.palette.mode === 'dark');
  }, [theme]);

  return (
    <MenuItem style={{ display: "flex", gap: "10px" }}>
      <DarkModeIcon />
      <Switch
        checked={themeSwitch}
        onChange={(event) => {
          const isChecked = event.target.checked;
          setThemeSwitch(isChecked);
          toggleTheme(isChecked);
        }}
      />
    </MenuItem>
  );
};

export default ThemeToggle;
