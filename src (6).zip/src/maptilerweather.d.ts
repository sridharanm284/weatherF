declare const maptilerweather: any;
