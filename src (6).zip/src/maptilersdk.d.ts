declare const maptilersdk: any;
