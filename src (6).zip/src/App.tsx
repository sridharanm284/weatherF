// src/App.tsx
import React from 'react';
import { ThemeProvider } from './ThemeContext'; 
import MainComponent from './main';
import './styles/_app.scss';

function App() {
  return (
    <ThemeProvider>
      <MainComponent />
    </ThemeProvider>
  );
}

export default App;
