// src/global.d.ts
interface Window {
    maptilersdk: any;
    maptilerweather: any;
  }