// typings.d.ts
declare module 'maptiler-sdk' {
    const maptilerSdk: any;
    export default maptilerSdk;
   }
   declare module 'maptiler-weather' {
    const maptilerWeather: any;
    export default maptilerWeather;
   }