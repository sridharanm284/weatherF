import { useState, useRef, useEffect } from 'react';
import './styles/_index.scss';
import store from '../../store';
import Box from '@mui/material/Box';
import { useSelector } from 'react-redux';
import { styled } from '@mui/material/styles';
import { Card, Typography } from '@mui/material';
import Grid from '@mui/material/Unstable_Grid2';
import CardPlan from '../../components/dashboard/card';
import MuiAppBar, { AppBarProps as MuiAppBarProps } from '@mui/material/AppBar';

const drawerWidth = 0;

const Main = styled('main', { shouldForwardProp: (prop) => prop !== 'open' })<{
	open?: boolean;
}>(({ theme, open }) => ({
	flexGrow: 1,
	padding: theme.spacing(3),
	transition: theme.transitions.create('margin', {
		easing: theme.transitions.easing.sharp,
		duration: theme.transitions.duration.leavingScreen,
	}),
	marginLeft: `-${drawerWidth}px`,
	...(open && {
		transition: theme.transitions.create('margin', {
			easing: theme.transitions.easing.easeOut,
			duration: theme.transitions.duration.enteringScreen,
		}),
		marginLeft: 0,
	}),
}));

interface AppBarProps extends MuiAppBarProps {
	open?: boolean;
}

const AppBar = styled(MuiAppBar, {
	shouldForwardProp: (prop) => prop !== 'open',
})<AppBarProps>(({ theme, open }) => ({
	transition: theme.transitions.create(['margin', 'width'], {
		easing: theme.transitions.easing.sharp,
		duration: theme.transitions.duration.leavingScreen,
	}),
	...(open && {
		width: `calc(100% - ${drawerWidth}px)`,
		marginLeft: `${drawerWidth}px`,
		transition: theme.transitions.create(['margin', 'width'], {
			easing: theme.transitions.easing.easeOut,
			duration: theme.transitions.duration.enteringScreen,
		}),
	}),
}));

export default function DashBoard() {
	// Reference value for current Browser Window Width
	const windowWidth = useRef(window.innerWidth);

	// Sets Track about the SideNav Bar Open/Close State
	const [open, setOpen] = useState(windowWidth.current > 1000 ? true : false);
	const data = useSelector((state: any) => state?.app);
	useEffect(() => {
		store.dispatch({
			type: 'TOGGLE_MENU',
			payload: windowWidth.current > 1000 ? true : false,
		});
	}, []);

	useEffect(() => {
		setOpen(data.toggle);
	}, [data]);

	return (
		<div className={open ? 'sideNavOpen' : 'sideNavClose'}>
			{/* <AppBar open={open} position='sticky'>
				<Header className={data.toggle ? 'headerpadding' : null} />
			</AppBar> */}

			<Box className='ailevate-container bg-default flex sidenav-full'>
				<div className='content-wrap dashboard'>
					{/* <Drawer
						sx={{
							'width': drawerWidth,
							'flexShrink': 0,
							'& .MuiDrawer-paper': {
								width: drawerWidth,
								boxSizing: 'border-box',
							},
						}}
						variant='persistent'
						anchor='left'
						open={open}>
						<SideNavMenu />
					</Drawer> */}
					<Main open={open} className={'main'}>
						<Grid container spacing={2} display={'flex'} alignItems={'center'}>
							<Grid xs={12} md={9}>
								<Grid container spacing={3}>
									<CardPlan />
								</Grid>
							</Grid>
							<Grid xs={12} md={3} marginTop={'2em'} height={'63vh'}>
								<Card
									style={{
										height: '100%',
										borderRadius: '15px',
									}}>
									<Grid xs={12} sx={{ height: 150 }}>
										<Typography
											variant='body2'
											color='text.secondary'
											style={{ textAlign: 'center' }}>
											Active Warnings
										</Typography>
									</Grid>
									<Grid xs={12} sx={{ height: 150 }}>
										<Typography
											variant='body2'
											color='text.secondary'
											style={{ textAlign: 'center' }}>
											Squall Warnings
										</Typography>
									</Grid>
									<Grid xs={12} sx={{ height: 150 }}>
										<Typography
											variant='body2'
											color='text.secondary'
											style={{ textAlign: 'center' }}>
											Typhoon Warnings
										</Typography>
									</Grid>
								</Card>
							</Grid>
						</Grid>
					</Main>
				</div>
			</Box>
		</div>
	);
}
