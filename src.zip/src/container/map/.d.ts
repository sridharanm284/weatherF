declare module 'netcdfjs' {
    export default class NetCDF {
      constructor(arrayBuffer: ArrayBuffer);
      // Add other methods you find from the documentation
    }
  }
  