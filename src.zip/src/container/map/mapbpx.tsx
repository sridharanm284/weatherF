

  function WeatherMap() {
  }

  export default WeatherMap;
