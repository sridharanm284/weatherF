import React, { useState, useEffect, useRef } from 'react';
import store from '../../store';
import { useSelector } from 'react-redux';
import './style/_index.scss';
import ReactMapGL, { Marker } from 'react-map-gl';
import { Point } from 'mapbox-gl';

const ChartComponent: React.FC = () => {
  const data = useSelector((state: any) => state?.app);
  const [sn, setSn] = useState(localStorage.getItem('sideNav'));
  const windowWidth = useRef(window.innerWidth);
  const [open, setOpen] = useState(windowWidth.current > 1000 ? true : false);
  const [dir, setDir] = useState<{ lon: any; lat: any }>({
    lon: localStorage.getItem('lon')
      ? localStorage.getItem('lon')
      : '79.62419094596439',
    lat: localStorage.getItem('lat')
      ? localStorage.getItem('lat')
      : '11.923681405362505',
  });
  const [viewPort, setViewPort] = useState({
    latitude: parseFloat(dir.lat), // Change to 'latitude' instead of 'lat'
    longitude: parseFloat(dir.lon), // Change to 'longitude' instead of 'lon'
    zoom: 14,
  });
  const [newPlace, setNewPlace] = useState<any>(null);

  // Other useEffect and code...

  return (
    <ReactMapGL
      mapboxAccessToken='pk.eyJ1IjoiZHNkYXNhIiwiYSI6ImNsa2sxdTNjaTA2dngzcGw5azhzYWs0cHIifQ.wtLPlIIY7fhiHGrgO85YRg'
      {...viewPort}
      style={{
        position: 'absolute',
        width: '100%',
        height: '100%',
        zIndex: 999,
      }}
      mapStyle='mapbox://styles/mapbox/streets-v9'>
      <Marker
        longitude={viewPort.longitude} // Use 'longitude' instead of 'lon'
        latitude={viewPort.latitude}> // Use 'latitude' instead of 'lat'
        <div style={{ color: 'red', fontSize: '14px' }}>📍</div>
      </Marker>
    </ReactMapGL>
  );
};

export default ChartComponent;
