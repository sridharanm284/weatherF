import { useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import {
	IconButton,
	MenuItem,
	Box,
	Avatar,
	Menu,
	Typography,
	Button,
	TextField,
	Dialog,
	DialogActions,
	DialogContent,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import PasswordIcon from "@mui/icons-material/Password";
import { useState } from "react";
import HeaderTitle from "./title";
import store from "../../store";
import LogoutIcon from "@mui/icons-material/Logout";
import DarkModeIcon from "@mui/icons-material/DarkMode";
import SettingsIcon from "@mui/icons-material/Settings";

const themes = ["Dark", "Light"];
const settings = [
	{ name: "Theme", icon: <DarkModeIcon style={{ fontSize: "20px" }} /> },
	{ name: "Settings", icon: <SettingsIcon style={{ fontSize: "20px" }} /> },
	{ name: "Signout", icon: <LogoutIcon style={{ fontSize: "20px" }} /> },
];

const Header = (props: any) => {
	const mystyle = {
		arrowIcon: {
			color: "white",
		},
		header: {
			backgroundColor: "black",
			padding: "10px 20px",
			color: "white",
		},
		content: {
			padding: "0 20px",
		},
	};
	const location = useLocation();
	const navigate = useNavigate();
	const data = useSelector((state: any) => state?.app);

	const handleToggle = () => {
		store.dispatch({
			type: "TOGGLE_MENU",
			payload: data.toggle ? false : true,
		});
	};

	const [anchorElUser, setAnchorElUser] = useState<null | HTMLElement>(null);
	const [sanchorElUser, setsAnchorElUser] = useState<null | HTMLElement>(
		null
	);
	const [modalOpen, setModalOpen] = useState(false);
	const [passmodalOpen, setPassModalOpen] = useState(false);
	const [userModal, setUserModal] = useState<any | {}>({
		name: localStorage.getItem("user_name"),
		id: localStorage.getItem("user_id"),
		email: localStorage.getItem("email"),
		tel: localStorage.getItem("tel"),
	});
	const [passwordModal, setPasswordModal] = useState<any | {}>({
		id: localStorage.getItem("user_id"),
		password: localStorage.getItem("password"),
		old_password: localStorage.getItem("old_password"),
		c_password: localStorage.getItem("c_password"),
	});

	const handleOpenUserMenu = (event: React.MouseEvent<HTMLElement>) => {
		setAnchorElUser(event.currentTarget);
	};

	const handleOpenUserMenus = (
		event: React.MouseEvent<HTMLElement>,
		option: any
	) => {
		if (option === "Settings") {
			setModalOpen(true);
			setPassModalOpen(false);
			setsAnchorElUser(null);
			setAnchorElUser(null);
		} else if (option === "change_password") {
			setModalOpen(false);
			setPassModalOpen(true);
			setsAnchorElUser(null);
			setAnchorElUser(null);
		} else if (option === "Theme") {
			setsAnchorElUser(event.currentTarget);
		} else if (option === "Signout") {
			localStorage.removeItem("token");
			localStorage.removeItem("login");
			localStorage.removeItem("user");
			localStorage.removeItem("user_id");
			localStorage.setItem("sideNav", "true");
			window.location.href = "/auth";
		}
	};

	const handleCloseUserMenu = () => {
		setsAnchorElUser(null);
		setAnchorElUser(null);
	};
	const handleClose = () => {
		setModalOpen(false);
		setPassModalOpen(false);
	};

	const updatedata = async () => {
		const res = await fetch("http://127.0.0.1:8000/api/user/update", {
			method: "POST",
			body: JSON.stringify(userModal),
			headers: {
				"Content-type": "application/json; charset=UTF-8",
				Authorization: "Basic " + btoa("admin:admin"),
			},
		});
		if (res.status === 200) {
			localStorage.clear();
			window.location.href = "/auth";
		} else {
			window.location.reload();
		}
	};

	return (
		<>
			<div className={props.className}>
				<div className="topbar">
					<div className="topbar-hold fixed">
						<div className="flex flex-space-between flex-middle h-100">
							<div className="flex">
								<IconButton onClick={handleToggle}>
									<MenuIcon style={{ color: "white" }} />
								</IconButton>
							</div>
							<div
								className="flex flex-middle"
								style={{ marginRight: "2em" }}
							>
								<Box
									sx={{ flexGrow: 0 }}
									style={{
										display: "flex",
										alignItems: "center",
										marginRight: "0px",
									}}
								>
									<button
										onClick={handleOpenUserMenu}
										style={{
											display: "flex",
											alignItems: "center",
											justifyContent: "center",
											background: "transparent",
											border: "none",
											cursor: "pointer",
										}}
									>
										<Avatar>
											{localStorage
												.getItem("user_name")
												?.slice(0, 1)}
										</Avatar>
									</button>
									<Menu
										sx={{ mt: "32px" }}
										id="menu-appbar"
										anchorEl={anchorElUser}
										anchorOrigin={{
											vertical: "top",
											horizontal: "right",
										}}
										keepMounted
										transformOrigin={{
											vertical: "top",
											horizontal: "right",
										}}
										open={Boolean(anchorElUser)}
										onClose={handleCloseUserMenu}
									>
										{settings.map((setting) => (
											<MenuItem
												style={{
													display: "flex",
													gap: "10px",
												}}
												key={setting.name}
												onClick={(e: any) =>
													handleOpenUserMenus(
														e,
														setting.name
													)
												}
											>
												{setting.icon}{" "}
												<Typography textAlign={"left"}>
													{setting.name}
												</Typography>
											</MenuItem>
										))}
									</Menu>
									<Menu
										sx={{ mt: "32px" }}
										id="menu-appbar"
										anchorEl={sanchorElUser}
										anchorOrigin={{
											vertical: "top",
											horizontal: "left",
										}}
										keepMounted
										transformOrigin={{
											vertical: "top",
											horizontal: "right",
										}}
										open={Boolean(sanchorElUser)}
										onClose={handleCloseUserMenu}
									>
										{themes.map((theme) => (
											<MenuItem
												key={theme}
												onClick={handleCloseUserMenu}
											>
												<Typography textAlign="center">
													{theme}
												</Typography>
											</MenuItem>
										))}
									</Menu>
								</Box>
							</div>
						</div>
					</div>
				</div>
				<Dialog open={modalOpen} onClose={handleClose}>
					<h4
						className="header_title_settings"
						style={{
							padding: 10,
							backgroundColor: "black",
							color: "yellow",
						}}
					>
						Settings
					</h4>
					<p style={mystyle.content}>Personal Detail</p>
					<DialogContent
						style={{
							padding: "0 24px",
							display: "flex",
							flexDirection: "column",
							gap: 4,
							width: 600,
						}}
					>
						<TextField
							autoFocus
							margin="dense"
							id="name"
							label="Name"
							type="text"
							fullWidth
							defaultValue={userModal.name}
							onChange={(e: any) => {
								setUserModal({
									...userModal,
									name: e.target.value,
								});
							}}
							variant="outlined"
							size="small"
						/>
						<TextField
							autoFocus
							margin="dense"
							id="email"
							label="Email Address"
							type="text"
							fullWidth
							defaultValue={userModal.email}
							onChange={(e: any) => {
								setUserModal({
									...userModal,
									email: e.target.value,
								});
							}}
							variant="outlined"
							size="small"
						/>
						<TextField
							autoFocus
							margin="dense"
							id="mobile"
							label="Mobile"
							type="text"
							defaultValue={userModal.tel}
							onChange={(e: any) => {
								setUserModal({
									...userModal,
									tel: e.target.value,
								});
							}}
							fullWidth
							variant="outlined"
							size="small"
						/>

						<Button
							style={{
								marginTop: "20px",
								width: "fit-content",
								gap: "10px",
								border: "1.75px solid #384e73",
							}}
							onClick={(e: any) =>
								handleOpenUserMenus(e, "change_password")
							}
						>
							<PasswordIcon fontSize="small" /> Change Password
						</Button>
					</DialogContent>
					<DialogActions>
						<Button variant="outlined" onClick={handleClose}>
							Cancel
						</Button>
						<Button variant="outlined" onClick={updatedata}>
							Update Details
						</Button>
					</DialogActions>
				</Dialog>
				<Dialog open={passmodalOpen} onClose={handleClose}>
					<h4
						className="header_title_settings"
						style={{
							padding: 10,
							backgroundColor: "black",
							color: "yellow",
						}}
					>
						Change Password
					</h4>
					<DialogContent>
						<TextField
							autoFocus
							margin="dense"
							id="old_pass"
							label="Old Password"
							type="text"
							fullWidth
							variant="standard"
						/>
						<TextField
							autoFocus
							margin="dense"
							id="new_pass"
							label="New Password"
							type="text"
							fullWidth
							variant="standard"
						/>
						<TextField
							autoFocus
							margin="dense"
							id="new_pass_confirm"
							label="Confirm New Password"
							type="text"
							fullWidth
							variant="standard"
						/>
					</DialogContent>
					<DialogActions>
						<Button variant="contained" onClick={handleClose}>
							Update Password
						</Button>
						<Button variant="contained" onClick={handleClose}>
							Cancel
						</Button>
					</DialogActions>
				</Dialog>
			</div>
		</>
	);
};
export default Header;