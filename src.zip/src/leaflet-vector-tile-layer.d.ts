declare module 'leaflet-vector-tile-layer' {
    import * as L from 'leaflet';
    export default function VectorTileLayer(options: any): L.TileLayer;
  }
  