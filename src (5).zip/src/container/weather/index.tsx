import store from "../../store";
import Box from "@mui/material/Box";
import { useSelector } from "react-redux";
import { styled } from "@mui/material/styles";
import { useState, useRef, useEffect } from "react";
import MuiAppBar, { AppBarProps as MuiAppBarProps } from "@mui/material/AppBar";
import WeatherLoader from "../../components/loader";
import "./styles/_index.scss";

const drawerWidth = 240;

const Main = styled("main", { shouldForwardProp: (prop) => prop !== "open" })<{
  open?: boolean;
}>(({ theme, open }) => ({
  flexGrow: 1,
  padding: theme.spacing(3),
  transition: theme.transitions.create("margin", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  marginLeft: `-${drawerWidth}px`,
  ...(open && {
    transition: theme.transitions.create("margin", {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
    marginLeft: 0,
  }),
}));

interface AppBarProps extends MuiAppBarProps {
  open?: boolean;
}

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== "open",
})<AppBarProps>(({ theme, open }) => ({
  transition: theme.transitions.create(["margin", "width"], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    width: `calc(100% - ${drawerWidth}px)`,
    marginLeft: `${drawerWidth}px`,
    transition: theme.transitions.create(["margin", "width"], {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

export default function Weather() {
  // Reference value for current Browser Window Width
  const windowWidth = useRef(window.innerWidth);

  // Sets Track about the SideNav Bar Open/Close State
  const [open, setOpen] = useState(windowWidth.current > 1000 ? true : false);
  const data = useSelector((state: any) => state?.app);

  const [criteriaDatas, setCriteriaDatas] = useState<any>([]);
  const [criteriaDetailDatas, setCriteriaDetailDatas] = useState<any>([]);
  const [TableDatas, setTableDatas] = useState<any>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    store.dispatch({
      type: "TOGGLE_MENU",
      payload: windowWidth.current > 1000 ? true : false,
    });
  }, []);

  useEffect(() => {
    setOpen(data.toggle);
  }, [data]);

  useEffect(() => {
    const getData = async () => {
      await setLoading(true);
      await fetch(`http://localhost:8000/api/weather/`, {
        method: "POST",
        body: JSON.stringify({ forecast_id: localStorage.getItem("fid") }),
        headers: {
          "Content-type": "application/json; charset=UTF-8",
          Authorization: "Basic " + btoa("admin:admin"),
        },
        cache: "no-cache",
      })
        .then((response) => {
          return response.json();
        })
        .then((datas) => {
          let data = {
                "criteria_datas": [
                    {
                        "forecast_osf_criteria_id": 3966,
                        "forecast_id": 4905,
                        "criteria_name": "Winds > 40 knots OR Hs Combined > 5.0m"
                    },
                    {
                        "forecast_osf_criteria_id": 3967,
                        "forecast_id": 4905,
                        "criteria_name": "Winds > 25 knots OR Hs Combined > 2.5m"
                    },
                    {
                        "forecast_osf_criteria_id": 3968,
                        "forecast_id": 4905,
                        "criteria_name": "Winds > 15 knots OR Hs Combined > 1.5m"
                    }
                ],
                "criteria_detail_datas": [
                    {
                        "forecast_osf_criteria_id": 3966,
                        "field_id": 62,
                        "value": "5.00",
                        "margin_value": "3.50"
                    },
                    {
                        "forecast_osf_criteria_id": 3966,
                        "field_id": 2,
                        "value": "40.00",
                        "margin_value": "30.00"
                    },
                    {
                        "forecast_osf_criteria_id": 3967,
                        "field_id": 2,
                        "value": "25.00",
                        "margin_value": "20.00"
                    },
                    {
                        "forecast_osf_criteria_id": 3967,
                        "field_id": 62,
                        "value": "2.50",
                        "margin_value": "2.00"
                    },
                    {
                        "forecast_osf_criteria_id": 3968,
                        "field_id": 62,
                        "value": "1.50",
                        "margin_value": "1.20"
                    },
                    {
                        "forecast_osf_criteria_id": 3968,
                        "field_id": 2,
                        "value": "15.00",
                        "margin_value": "12.00"
                    }
                ],
                "datas": [
                    [
                        {
                            "datetimeutc": "01/31/2024 03:30",
                            "a_10mwindspeed": 9.0,
                            "a_10mwinddir": 209.0,
                            "sigwaveheight": 0.81
                        },
                        {
                            "datetimeutc": "01/31/2024 06:30",
                            "a_10mwindspeed": 8.0,
                            "a_10mwinddir": 205.0,
                            "sigwaveheight": 0.75
                        },
                        {
                            "datetimeutc": "01/31/2024 09:30",
                            "a_10mwindspeed": 7.0,
                            "a_10mwinddir": 199.0,
                            "sigwaveheight": 0.71
                        },
                        {
                            "datetimeutc": "01/31/2024 12:30",
                            "a_10mwindspeed": 7.0,
                            "a_10mwinddir": 177.0,
                            "sigwaveheight": 0.71
                        },
                        {
                            "datetimeutc": "01/31/2024 15:30",
                            "a_10mwindspeed": 11.0,
                            "a_10mwinddir": 166.0,
                            "sigwaveheight": 0.75
                        },
                        {
                            "datetimeutc": "01/31/2024 18:30",
                            "a_10mwindspeed": 13.0,
                            "a_10mwinddir": 184.0,
                            "sigwaveheight": 0.81
                        },
                        {
                            "datetimeutc": "01/31/2024 21:30",
                            "a_10mwindspeed": 12.0,
                            "a_10mwinddir": 203.0,
                            "sigwaveheight": 0.81
                        },
                        {
                            "datetimeutc": "01/31/2024 24:00",
                            "a_10mwindspeed": 11.0,
                            "a_10mwinddir": 208.0,
                            "sigwaveheight": 0.81
                        }
                    ],
                    [
                        {
                            "datetimeutc": "02/01/2024 03:30",
                            "a_10mwindspeed": 13.0,
                            "a_10mwinddir": 199.0,
                            "sigwaveheight": 0.81
                        },
                        {
                            "datetimeutc": "02/01/2024 06:30",
                            "a_10mwindspeed": 11.0,
                            "a_10mwinddir": 206.0,
                            "sigwaveheight": 0.81
                        },
                        {
                            "datetimeutc": "02/01/2024 09:30",
                            "a_10mwindspeed": 11.0,
                            "a_10mwinddir": 201.0,
                            "sigwaveheight": 0.81
                        },
                        {
                            "datetimeutc": "02/01/2024 12:30",
                            "a_10mwindspeed": 12.0,
                            "a_10mwinddir": 180.0,
                            "sigwaveheight": 0.88
                        },
                        {
                            "datetimeutc": "02/01/2024 15:30",
                            "a_10mwindspeed": 12.0,
                            "a_10mwinddir": 184.0,
                            "sigwaveheight": 0.88
                        },
                        {
                            "datetimeutc": "02/01/2024 18:30",
                            "a_10mwindspeed": 14.0,
                            "a_10mwinddir": 202.0,
                            "sigwaveheight": 0.95
                        },
                        {
                            "datetimeutc": "02/01/2024 21:30",
                            "a_10mwindspeed": 13.0,
                            "a_10mwinddir": 205.0,
                            "sigwaveheight": 0.99
                        },
                        {
                            "datetimeutc": "02/01/2024 24:00",
                            "a_10mwindspeed": 12.0,
                            "a_10mwinddir": 204.0,
                            "sigwaveheight": 0.81
                        }
                    ],
                    [
                        {
                            "datetimeutc": "02/02/2024 03:30",
                            "a_10mwindspeed": 11.0,
                            "a_10mwinddir": 212.0,
                            "sigwaveheight": 0.93
                        },
                        {
                            "datetimeutc": "02/02/2024 06:30",
                            "a_10mwindspeed": 11.0,
                            "a_10mwinddir": 223.0,
                            "sigwaveheight": 0.93
                        },
                        {
                            "datetimeutc": "02/02/2024 09:30",
                            "a_10mwindspeed": 9.0,
                            "a_10mwinddir": 212.0,
                            "sigwaveheight": 0.81
                        },
                        {
                            "datetimeutc": "02/02/2024 12:30",
                            "a_10mwindspeed": 8.0,
                            "a_10mwinddir": 195.0,
                            "sigwaveheight": 0.77
                        },
                        {
                            "datetimeutc": "02/02/2024 15:30",
                            "a_10mwindspeed": 10.0,
                            "a_10mwinddir": 209.0,
                            "sigwaveheight": 0.81
                        },
                        {
                            "datetimeutc": "02/02/2024 18:30",
                            "a_10mwindspeed": 10.0,
                            "a_10mwinddir": 220.0,
                            "sigwaveheight": 0.75
                        },
                        {
                            "datetimeutc": "02/02/2024 21:30",
                            "a_10mwindspeed": 11.0,
                            "a_10mwinddir": 218.0,
                            "sigwaveheight": 0.81
                        },
                        {
                            "datetimeutc": "02/02/2024 24:00",
                            "a_10mwindspeed": 12.0,
                            "a_10mwinddir": 207.0,
                            "sigwaveheight": 0.98
                        }
                    ],
                    [
                        {
                            "datetimeutc": "02/03/2024 03:30",
                            "a_10mwindspeed": 7.0,
                            "a_10mwinddir": 233.0,
                            "sigwaveheight": 0.67
                        },
                        {
                            "datetimeutc": "02/03/2024 06:30",
                            "a_10mwindspeed": 6.0,
                            "a_10mwinddir": 237.0,
                            "sigwaveheight": 0.65
                        },
                        {
                            "datetimeutc": "02/03/2024 09:30",
                            "a_10mwindspeed": 5.0,
                            "a_10mwinddir": 215.0,
                            "sigwaveheight": 0.65
                        },
                        {
                            "datetimeutc": "02/03/2024 12:30",
                            "a_10mwindspeed": 7.0,
                            "a_10mwinddir": 171.0,
                            "sigwaveheight": 0.65
                        },
                        {
                            "datetimeutc": "02/03/2024 15:30",
                            "a_10mwindspeed": 8.0,
                            "a_10mwinddir": 192.0,
                            "sigwaveheight": 0.6
                        },
                        {
                            "datetimeutc": "02/03/2024 18:30",
                            "a_10mwindspeed": 7.0,
                            "a_10mwinddir": 222.0,
                            "sigwaveheight": 0.57
                        },
                        {
                            "datetimeutc": "02/03/2024 21:30",
                            "a_10mwindspeed": 7.0,
                            "a_10mwinddir": 242.0,
                            "sigwaveheight": 0.57
                        },
                        {
                            "datetimeutc": "02/03/2024 24:00",
                            "a_10mwindspeed": 10.0,
                            "a_10mwinddir": 215.0,
                            "sigwaveheight": 0.75
                        }
                    ],
                    [
                        {
                            "datetimeutc": "02/04/2024 03:30",
                            "a_10mwindspeed": 4.0,
                            "a_10mwinddir": 307.0,
                            "sigwaveheight": 0.51
                        },
                        {
                            "datetimeutc": "02/04/2024 06:30",
                            "a_10mwindspeed": 4.0,
                            "a_10mwinddir": 353.0,
                            "sigwaveheight": 0.51
                        },
                        {
                            "datetimeutc": "02/04/2024 09:30",
                            "a_10mwindspeed": 5.0,
                            "a_10mwinddir": 156.0,
                            "sigwaveheight": 0.51
                        },
                        {
                            "datetimeutc": "02/04/2024 12:30",
                            "a_10mwindspeed": 6.0,
                            "a_10mwinddir": 135.0,
                            "sigwaveheight": 0.51
                        },
                        {
                            "datetimeutc": "02/04/2024 15:30",
                            "a_10mwindspeed": 7.0,
                            "a_10mwinddir": 135.0,
                            "sigwaveheight": 0.51
                        },
                        {
                            "datetimeutc": "02/04/2024 18:30",
                            "a_10mwindspeed": 7.0,
                            "a_10mwinddir": 157.5,
                            "sigwaveheight": 0.51
                        },
                        {
                            "datetimeutc": "02/04/2024 21:30",
                            "a_10mwindspeed": 8.0,
                            "a_10mwinddir": 202.5,
                            "sigwaveheight": 0.54
                        },
                        {
                            "datetimeutc": "02/04/2024 24:00",
                            "a_10mwindspeed": 6.0,
                            "a_10mwinddir": 271.0,
                            "sigwaveheight": 0.57
                        }
                    ],
                    [
                        {
                            "datetimeutc": "02/05/2024 24:00",
                            "a_10mwindspeed": 9.0,
                            "a_10mwinddir": 225.0,
                            "sigwaveheight": 0.6
                        }
                    ]
                ]
            }
          setCriteriaDatas(data.criteria_datas);
          setCriteriaDetailDatas(data.criteria_detail_datas);
          setTableDatas(data.datas);
        })
        .catch((error) => {
          console.log("Cannot Fetch Table Datas");
        });
      await setLoading(false);
    };
    getData();
  }, []);

  function dateFormat(date: Date) {
    var montharray = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ];
    let d;
    if(date.getHours() === 0)
      d = date.getDate() - 1;
    else
      d = date.getDate();
    var m = montharray[date.getMonth()];
    return d + " " + m;
  }

  function getColor(data: number, selectvalue: number) {
    let criteria: any = {};
    let fieldId2: any = {};
    let fieldId62: any = {};
    let operatorId: number | undefined;
    criteriaDetailDatas.forEach((c_data: any) => {
      if (parseInt(c_data.forecast_osf_criteria_id) === selectvalue) {
        criteria = c_data;
        if (c_data.field_id === 2) {
          fieldId2 = c_data;
        } else if (c_data.field_id === 62) {
          fieldId62 = c_data;
        }
        operatorId = c_data.comparison_operator_id;
      }
    });
    let isAndOperator = operatorId === 2;
    let isField2Green = data <= fieldId2.margin_value;
    let isField2Yellow = data > fieldId2.margin_value && data <= criteria.value;
    let isField2Red = data > criteria.value;
    let isField62Green = data <= fieldId62.margin_value;
    let isField62Yellow = data > fieldId62.margin_value && data <= criteria.value;
    let isField62Red = data > criteria.value;
    if ((isField2Green && isField62Green && isAndOperator) || (isField2Green || isField62Green && !isAndOperator)) {
      return "green_overview";
    } else if ((isField2Yellow && isField62Yellow && isAndOperator) || (isField2Yellow || isField62Yellow && !isAndOperator)) {
      return "yellow_overview";
    } else {
      return "red_overview";
    }
   }

  return (
    <div className={open ? "sideNavOpen" : "sideNavClose"}>
      <Box className="fug-container bg-default flex sidenav-full">
        <div className="content-wrap dashboard">
          {!loading ? (
            criteriaDatas?.length > 0 ? (
              <Main
                open={open}
                className={"main"}
                style={{
                  overflow: "auto",
                  display: "flex",
                  paddingBlock: "10px",
                  flexDirection: "column",
                  justifyContent: "center",
                  gap: "35px",
                }}
              >
                <div className={"heading_div"}></div>
                <div className={"maincontainer"}>
                  {TableDatas.map((datas: any) => (
                    <>
                      <div key={Math.random()} className={"mini_header_box"}>
                        <div className={"mini_header_main"}>
                          <span className={"mini_header_date"}>
                            {dateFormat(new Date(datas[0].datetimeutc))}
                          </span>
                        </div>
                        <div className={"mini_header_time"}>
                          {datas.map((data: any) => (
                            <span
                              key={Math.random()}
                              className={"mini_header_time"}
                            >
                              {new Date(data.datetimeutc).getHours() === 0
                                ? 24
                                : new Date(data.datetimeutc).getHours()}
                            </span>
                          ))}
                        </div>
                        {criteriaDatas?.map((rows: any) => (
                          <>
                            <span
                              key={Math.random()}
                              style={{ textAlign: "center" }}
                            >
                              {rows.criteria_name}
                            </span>
                            <div className={"mini_color_box"}>
                              {datas.map((data: any, index: number) => (
                                <span
                                  key={Math.random()}
                                  style={{ width: "100%" }}
                                  className={getColor(
                                    data.a_10mwindspeed,
                                    parseInt(rows.forecast_osf_criteria_id)
                                  )}
                                ></span>
                              ))}
                            </div>
                          </>
                        ))}
                      </div>
                    </>
                  ))}
                </div>
                <div className={"legend_div"}>
                  <span className={"legend_heading"}>Status</span>
                  <div className={"lengend_details_div"}>
                    <div className={"legend_inner_div"}>
                      <span
                        style={{ width: "2.5em" }}
                        className={["high_legend"].join(" ")}
                      ></span>
                      <span className={"legend_content"}>Above the limit</span>
                    </div>
                    <div className={"legend_inner_div"}>
                      <span
                        style={{ width: "2.5em" }}
                        className={["normal_legend"].join(" ")}
                      ></span>
                      <span className={"legend_content"}>Marginal</span>
                    </div>
                    <div className={"legend_inner_div"}>
                      <span
                        style={{ width: "2.5em" }}
                        className={["low_legend"].join(" ")}
                      ></span>
                      <span className={"legend_content"}>Below the limit</span>
                    </div>
                  </div>
                </div>
              </Main>
            ) : loading === false ? (
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  height: "90vh",
                }}
              >
                <p
                  style={{
                    fontSize: "28px",
                    color: "black",
                    backgroundColor: "grey",
                    padding: 10,
                    borderRadius: 6,
                  }}
                >
                  No Data Found
                </p>
              </div>
            ) : null
          ) : (
            <div
              style={{
                width: "100%",
                height: "90vh",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <WeatherLoader />
            </div>
          )}
        </div>
      </Box>
    </div>
  );
}
