import React from 'react';
import './styles/_index.scss';

const CustomSpinner: React.FC = () => {
  return (
      <div className="loader"></div>
  );
};

export default CustomSpinner;