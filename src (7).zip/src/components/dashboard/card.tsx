import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import squall from "./../../assets/squall.png";
import typhoon from "./../../assets/typhoon.png";
import forecast from "./../../assets/forecast.png";
import lightning from "./../../assets/lightning.png";
import quickOverview from "./../../assets/quick-overview.png";
import weatherWindow from "./../../assets/weather-window.png";
import { Grid, Card, CardMedia, CardContent, Typography } from "@mui/material";
import "./style.scss";
import MapComponent from "../MapComponent";
import axios from "axios";

interface CardData {
  name: string;
  url: string;
  image: string;
  content: string;
  color?: string;
}

const CardPlan: React.FC = () => {
  const [data, setData] = useState<CardData[]>([]);
  const [stormData, setStormData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchStormData();
    fetchLastEditedData();
  }, []);

  const fetchStormData = () => {
    // Hardcoded storm data
    const hardcodedData = {
      "track_datas": [
        {
          "storm_track_id": 371,
          "storm_name": "01W EWINIAR",
          "storm_description": null,
          "status_id": 8,
          "created_by": 22,
          "created_on": "2024-05-24",
          "updated_by": 18,
          "updated_on": "2024-05-27",
          "last_accessed_on": "2024-05-27T07:34:35.908553"
        }
      ],
      "storm_datas": [
        [
          {
            "storm_path_data_id": 34010,
            "storm_path_id": 4442,
            "id_index": 1,
            "lat": 29.339906506228946,
            "lon": 136.12518790248433,
            "date_utc": "2024-05-30T03:00:00",
            "time_utc": "2024-05-30T03:00:00",
            "heading": 40.495337828515346,
            "speed_kts": 22.17,
            "max_wind_speed": 50.0,
            "max_gust": 65.0,
            "central_pressure": 976.0,
            "output_unit_id": 24,
            "kts_34_ne": 60.0,
            "kts_34_se": 60.0,
            "kts_34_sw": 60.0,
            "kts_34_nw": 60.0,
            "kts_50_ne": 30.0,
            "kts_50_se": 30.0,
            "kts_50_sw": 30.0,
            "kts_50_nw": 30.0,
            "kts_64_ne": 0.0,
            "kts_64_se": 0.0,
            "kts_64_sw": 0.0,
            "kts_64_nw": 0.0,
            "kts_80_ne": 0.0,
            "kts_80_se": 0.0,
            "kts_80_sw": 0.0,
            "kts_80_nw": 0.0,
            "created_by": 25,
            "created_on": "2024-05-29T23:33:19.060271",
            "updated_by": 22,
            "updated_on": "2024-05-30T03:41:04.030393",
            "distance_in_miles": 266.0714009117437,
            "storm_category_id": 61,
            "last_accessed_on": "2024-05-29T23:33:19.199733"
          },
          {
            "storm_path_data_id": 34011,
            "storm_path_id": 4442,
            "id_index": 2,
            "lat": 32.525434701381656,
            "lon": 139.72176095661598,
            "date_utc": "2024-05-30T15:00:00",
            "time_utc": "2024-05-30T15:00:00",
            "heading": 54.356311492197506,
            "speed_kts": 22.67,
            "max_wind_speed": 45.0,
            "max_gust": 55.0,
            "central_pressure": 984.0,
            "output_unit_id": 24,
            "kts_34_ne": 50.0,
            "kts_34_se": 50.0,
            "kts_34_sw": 50.0,
            "kts_34_nw": 50.0,
            "kts_50_ne": 0.0,
            "kts_50_se": 0.0,
            "kts_50_sw": 0.0,
            "kts_50_nw": 0.0,
            "kts_64_ne": 0.0,
            "kts_64_se": 0.0,
            "kts_64_sw": 0.0,
            "kts_64_nw": 0.0,
            "kts_80_ne": 0.0,
            "kts_80_se": 0.0,
            "kts_80_sw": 0.0,
            "kts_80_nw": 0.0,
            "created_by": 25,
            "created_on": "2024-05-29T23:33:19.060271",
            "updated_by": 22,
            "updated_on": "2024-05-30T03:41:04.030393",
            "distance_in_miles": 272.0013146601995,
            "storm_category_id": 2,
            "last_accessed_on": "2024-05-29T23:33:19.199733"
          },
          {
            "storm_path_data_id": 34012,
            "storm_path_id": 4442,
            "id_index": 3,
            "lat": 35.140483933901415,
            "lon": 144.33661878995824,
            "date_utc": "2024-05-31T03:00:00",
            "time_utc": "2024-05-31T03:00:00",
            "heading": 59.18071845185432,
            "speed_kts": 24.9,
            "max_wind_speed": 40.0,
            "max_gust": 50.0,
            "central_pressure": 991.0,
            "output_unit_id": 24,
            "kts_34_ne": 40.0,
            "kts_34_se": 40.0,
            "kts_34_sw": 40.0,
            "kts_34_nw": 40.0,
            "kts_50_ne": 0.0,
            "kts_50_se": 0.0,
            "kts_50_sw": 0.0,
            "kts_50_nw": 0.0,
            "kts_64_ne": 0.0,
            "kts_64_se": 0.0,
            "kts_64_sw": 0.0,
            "kts_64_nw": 0.0,
            "kts_80_ne": 0.0,
            "kts_80_se": 0.0,
            "kts_80_sw": 0.0,
            "kts_80_nw": 0.0,
            "created_by": 25,
            "created_on": "2024-05-29T23:33:19.060271",
            "updated_by": 22,
            "updated_on": "2024-05-30T03:41:04.030393",
            "distance_in_miles": 298.83590333372,
            "storm_category_id": 2,
            "last_accessed_on": "2024-05-29T23:33:19.199733"
          },
          {
            "storm_path_data_id": 34013,
            "storm_path_id": 4442,
            "id_index": 4,
            "lat": 37.63850468248265,
            "lon": 149.75765746451773,
            "date_utc": "2024-05-31T15:00:00",
            "time_utc": "2024-05-31T15:00:00",
            "heading": 67.46268587881588,
            "speed_kts": 26.37,
            "max_wind_speed": 30.0,
            "max_gust": 40.0,
            "central_pressure": 997.0,
            "output_unit_id": 24,
            "kts_34_ne": 0.0,
            "kts_34_se": 0.0,
            "kts_34_sw": 0.0,
            "kts_34_nw": 0.0,
            "kts_50_ne": 0.0,
            "kts_50_se": 0.0,
            "kts_50_sw": 0.0,
            "kts_50_nw": 0.0,
            "kts_64_ne": 0.0,
            "kts_64_se": 0.0,
            "kts_64_sw": 0.0,
            "kts_64_nw": 0.0,
            "kts_80_ne": 0.0,
            "kts_80_se": 0.0,
            "kts_80_sw": 0.0,
            "kts_80_nw": 0.0,
            "created_by": 25,
            "created_on": "2024-05-29T23:33:19.060271",
            "updated_by": 22,
            "updated_on": "2024-05-30T03:41:04.030393",
            "distance_in_miles": 349.8382287994931,
            "storm_category_id": 5,
            "last_accessed_on": "2024-05-29T23:33:19.199733"
          }
        ]
      ]
    };
    setStormData(hardcodedData.storm_datas[0]);
    console.log("Storm data set:", hardcodedData.storm_datas[0]);
  };

  const returnTimeDifference = (date: string) => {
    const now = new Date();
    const pastDate = new Date(date);
    const timeDiff = Math.abs(now.getTime() - pastDate.getTime());
    const diffDays = Math.floor(timeDiff / (1000 * 3600 * 24));
    return diffDays + " days";
  };

  const fetchLastEditedData = async () => {
    const fid = '1792';  // Hardcoded fid value
    if (fid) {
      try {
        console.log("Fetching last edited data");
        // Simulate API response with hardcoded data
        const lastEditedData = {
          "forecast": "2024-01-31T00:30:00",
          "quick_overview": "2024-01-31T08:12:13.981582",
          "typhoon": "2024-05-31"
        };

        const cardData: CardData[] = [
          {
            name: "Forecast",
            url: "forecast",
            image: forecast,
            content: lastEditedData.forecast
              ? `Last edited ${returnTimeDifference(lastEditedData.forecast)} ago`
              : "",
          },
          {
            name: "Quick Overview",
            url: "overview",
            image: quickOverview,
            content: lastEditedData.quick_overview
              ? `Last edited ${returnTimeDifference(lastEditedData.quick_overview)} ago`
              : "",
          },
          {
            name: "Weather Window",
            url: "weather",
            image: weatherWindow,
            content: lastEditedData.quick_overview
              ? `Last edited ${returnTimeDifference(lastEditedData.quick_overview)} ago`
              : "",
          },
          {
            name: "Squall",
            url: "squall",
            image: squall,
            content: "",
            color: "green",
          },
          {
            name: "Typhoon",
            url: "typhoon",
            image: typhoon,
            content: lastEditedData.typhoon
              ? `Last edited ${returnTimeDifference(lastEditedData.typhoon)} ago`
              : "",
            color: stormData.length === 0 ? "green" : "red",
          },
          {
            name: "Lightning",
            url: "lightning",
            image: lightning,
            content: "",
            color: "green",
          },
        ];

        setData(cardData);
        console.log("Card data set:", cardData);
      } catch (error) {
        console.error("Error fetching last edited data:", error);
      }
    } else {
      console.log("No fid found");
      // Provide default data if no fid is found
      const defaultCardData: CardData[] = [
        {
          name: "Forecast",
          url: "forecast",
          image: forecast,
          content: "No data available",
        },
        {
          name: "Quick Overview",
          url: "overview",
          image: quickOverview,
          content: "No data available",
        },
        {
          name: "Weather Window",
          url: "weather",
          image: weatherWindow,
          content: "No data available",
        },
        {
          name: "Squall",
          url: "squall",
          image: squall,
          content: "",
          color: "green",
        },
        {
          name: "Typhoon",
          url: "typhoon",
          image: typhoon,
          content: "No data available",
          color: "green",
        },
        {
          name: "Lightning",
          url: "lightning",
          image: lightning,
          content: "",
          color: "green",
        },
      ];

      setData(defaultCardData);
      console.log("Default card data set:", defaultCardData);
    }
  };

  return (
    <div className="container">
      <div className="map-container">
        <MapComponent />
      </div>
      <div className="cards-container">
        <Grid container direction="row" wrap="nowrap" spacing={2} className="cards-grid">
          {data.map((item) => (
            <Grid item key={item.name} xs>
              <Link to={`/${item.url}`} state={{ title: item.name }}>
                <div className="hoverable">
                  <CardMedia
                    className="card-img"
                    sx={{ height: 100 }}
                    image={item.image}
                    title={item.name}
                    style={{ borderRadius: "10px" }}
                  />
                  <Card className="parent_card" style={{ borderRadius: "10px" }}>
                    <CardContent
                      className="child_card"
                      style={{
                        display: "flex",
                        flexDirection: "row",
                        justifyContent: "space-between",
                        alignItems: "center",
                      }}
                    >
                      <div>
                        <Typography gutterBottom variant="h6" component="div">
                          {item.name}
                        </Typography>
                        <Typography
                          variant="body2"
                          color="text.secondary"
                          style={{ fontSize: "0.8rem" }}
                        >
                          {item.content}
                        </Typography>
                      </div>
                      {item.color && (
                        <span
                          className={`color_icon ${
                            item.color === "red"
                              ? "color_icon_red blinking-circle"
                              : `color_icon_${item.color}`
                          }`}
                        ></span>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </Link>
            </Grid>
          ))}
        </Grid>
      </div>
    </div>
  );
};

export default CardPlan;